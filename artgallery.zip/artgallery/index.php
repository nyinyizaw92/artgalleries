<?php 
session_start();

if(isset($_COOKIE['username']))
{
  header('location:artgallery.php');
}

 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">

  <!--  -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <!--  -->
  <link rel="shortcut icon" href="img/favicon.png">


  <title>Art Gallery</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">

  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
 
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>

<body>
  <!-- container section start -->
  <section id="container" class="">


   <?php require_once('beforelogin.php'); ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          
          <div class="col-sm-12 col-lg-12 col-md-12">
             <div id="demo" class="carousel slide" data-ride="carousel">
                <!-- The slideshow -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="image/glasspainting.png" alt="Los Angeles" class="img-responsive">
                  </div>
                  <div class="carousel-item">
                    <img src="image/pastelpainting.png" alt="Chicago" class="img-responsive">
                  </div>
                  <div class="carousel-item">
                    <img src="image/oilpainting.png" alt="New York" class="img-responsive">
                  </div>
                </div>
                
                <!-- Left and right controls -->
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                  <span class="carousel-control-next-icon"></span>
                </a>
              </div>
           </div>

          
        </div>
        <!--end carousel-->

        <div class="row">
          <div class="col-sm-1"></div>
          <div class="col-sm-10">
              <h2>About Us</h2>
              <p>
                  Rating: 5 - ‎7 votes
                  Dec 7, 2018 - Well, how can anyone make that any simpler! But, is art painting as simple as it sounds? To be fair, it never is and never was. The art of painting ...
                  25 Different Types of Painting Techniques and Styles - Webneel.com
                  webneel.com/types-of-paintings-techniques-styles

                  Types of Paintings : Painting is the art of splashing colours with the help of brushes in a certain way to create an art.
                  7 Major Painting Styles, From Realism to Abstract - ThoughtCo
                  https://www.thoughtco.com › ... › Visual Arts › Art › Art History

                  Jan 6, 2019 - Part of the joy of painting in the 21st century is the range of available art styles. The late 19th and 20th centuries saw artists make huge leaps in ...
                  Types of Painters | Chron.com
                  https://work.chron.com › Career Advice › Stress & Work

                  Painting is one of the first skills children learn. Often, they learn how to paint -- in reality, they dabble or scrawl color on some surface -- before they learn to read .
              </p>
          </div>
          <div class="col-sm-1"></div>
        </div>
        <br>
        <!--start show some gallery-->
        <div class="row" style="margin-left:15px">
          <div class="col-sm-3 col-md-3 col-lg-3">
             <figure>
                <img src="image/glass painting.jpg" class="img-responsive rotate">
                <figcaption>Saint Tropez and its
                fort in the evening sun</figcaption>
             </figure>
              
          </div>
          <div class="col-sm-3 col-md-3 col-lg-3">
             <figure>
                <img src="image/glass painting.jpg" class="img-responsive rotate">
                <figcaption>Saint Tropez and its
                fort in the evening sun</figcaption>
             </figure>
          </div>

          <div class="col-sm-3 col-md-3 col-lg-3">
             <figure>
                <img src="image/glass painting.jpg" class="img-responsive rotate">
                <figcaption>Saint Tropez and its
                fort in the evening sun</figcaption>
             </figure>
          </div>
          <div class="col-sm-3 col-md-3 col-lg-3">
             <figure>
                <img src="image/glass painting.jpg" class="img-responsive rotate">
                <figcaption>Saint Tropez and its
                fort in the evening sun</figcaption>
             </figure>
          </div>
        </div>
        <!-- end show some gallery -->
     </section>
    </section>
    <!--main content end-->
  </section>
 
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>

    <script src="js/scripts.js"></script>
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });

      //for login form
      function loginform(){
        document.getElementById('show').style.display = "block";
         }

      function cancel(){
         document.getElementById('show').style.display = "none"; 
      }

     
    </script>

</body>

</html>
