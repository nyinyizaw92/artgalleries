<?php require_once('admin/db.php');

if(isset($_POST['register'])){

	$username = $_POST['username'];
	$useremail = $_POST['useremail'];
	$password = md5($_POST['userpassword']);
	$phoneCode = $_POST['phoneCode'];
	$phone = $_POST['phone'];
	
	
			$select = "SELECT username,useremail FROM register";
			$result = $conn->query($select);
			if($result->num_rows>0){
				while($row=$result->fetch_assoc()){
					
					$uname= $row['username'];
					$uemail= $row['useremail'];
						if($uname == $username && $uemail == $useremail){
						?>
							<!-- <div class="container" style="margin-top:20%">
								<center>
									<h4>Username or Email Alerady Exit</h4>
									<a href="index.php" class="btn btn-sm btn-danger">Ok</a>
								</center>
							</div> --><script type="text/javascript">
								alert('user name or useremail alerady exit');
							</script>
						<?php
						
					}else{
						$sql="INSERT INTO register (username,useremail,userpassword,phoneCode,phone) VALUES ('$username','$useremail','$password',$phoneCode,$phone)";

						if($conn->query($sql)==TRUE){
						?>
							<div class="container" style="margin-top:20px">
								<center>
									<h4>Register Successfully</h4>
									<a href="index.php" class="btn btn-sm btn-success">Ok</a>
								</center>
							</div>
						<?php
						
						}
						else{
						?>
						<div class="container" style="margin-top:20%">
								<center>
									<h4>Something Wrong Try it Again</h4>
									<a href="index.php" class="btn btn-sm btn-default">Ok</a>
								</center>
							</div>
						<?php
						
						}
					}
	


				}
					
			
		}


		
			}		



 ?>
 <!DOCTYPE html>
<html>
<head>
	<title>	Registeration Form</title>
	 <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.css" rel="stylesheet">
	</head>
<body>

 <div class="container">	
		<div class="row">
			<div class="col-sm-2 col-lg-2 col-md-2">	</div>
			<div class="col-sm-8 col-lg-8 col-md-8">	

					<form  action="register.php" method="post">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="username"  class="form-control" placeholder="enter your name" required>
                  </div>
                 
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="useremail" class="form-control" placeholder="enter your email" required>
                  </div>
                   
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="userpassword"  class="form-control" placeholder="enter your password" required>
                  </div>
                 
                  
                  <div class="form-group">
                    <label for="phone">Phone</label>
                    <select name="phoneCode" >
                      <option selected hidden value="" >Select Code</option>
                      <option value="95">+95</option>
                    </select>
                    <input type="phone" name="phone" class="form-control" placeholder="enter your phone no" required>
                  </div>
                <center> <button class="btn btn-primary" name="register">Signup</button></center>
                </form>
               </div>
               <div class="col-sm-2 col-md-2 col-lg-2"></div>
           </div>
          </div>
      </body>
      </html>