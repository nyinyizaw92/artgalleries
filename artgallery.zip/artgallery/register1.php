<!DOCTYPE html>
<html>
<head>
	<title>	Registeration Form</title>
	 <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.css" rel="stylesheet">
	</head>
<body>

	<?php 	


		$uname = $uemail = $upass = $comps ="";
		$username = $useremail = $userpassword = $confirmpass = "";
		$boolean =false;

		if($_SERVER["REQUEST_METHOD"] == "POST"){
			

			if(empty($_POST['useremail'])){
				$uemail = "Email Rquired";
				$boolean = false;

			}elseif(!filter_var($_POST['useremail'],FILTER_VALIDATE)){
					$useremail = "Imvalid Email";
					$boolean = false;
			}else{
				$useremail = validate_input($_POST['useremail']);
				$boolean = true;
			}

			$length = strlength($_POST['uesrpassword']);

			if(empty($_POST['userpassword'])){
				$upass = "password field required";
				$boolean = false;
			}elseif($length){
				$userpassword = $length;
				$boolean = true;
			}else{
				$userpassword = validate_input($_POST['userpassword']);
				$boolean = true;
			}

			if(empty($_POST["confirmpass"])){
				$conps = "confirm password required";
				$boolean = false;

			}elseif($_POST['confirmpass'] != $userpassword){
				$comps = "password not match";
				$boolean = false;
			}

			

			function strlength($str){
				$ln = strlen($str);
				if($ln > 15){
					return "Password should less than 15 character";
				}elseif($ln <5 && $ln >=1){
					return "password should greater than 3 character";
				}
				return;
			}

			function validate_input($data){
				$data = trim($data);
				$data = stripslashes($data);
				$data = htmlspecialchars($data);
				return $data;
			}
		}

		if($boolean){
			$dbname = "artgallery";
			$con = mysqli_conncet("localhost","root","",$dbname);
			if(!$con){
				die("connection failed" + mysqli_connect_error());
			}

			function NewUser(){
				$sql="INSERT INTO register (username,useremail,userpassword) VALUES ('$username',
				'$useremail','$userpassword')";

					$query = mysqli_query($GLOBALS['con'],$sql);

					if($query){
						echo "<script>
							alert('Record insert successfully');
							</script>
						";
					}

					function Signup(){
						$sql = "SELECT * FROM register username = '$username' AND useremail = '$useremail'";
						$result = mysqli_query($GLOBALS['con'],$sql);
						if(!$row = mysqli_fetch_array($result)){
							NewUser();
						}else{
							echo "<script>
									alert('you are alerady register');
									</script>";
						}
					}


						if(isset($_POST['register'])){
							$username = $_POST['username'];
							$useremail = $_POST['useremail'];
							$userpassword = $_POST['userpassword'];
							Signup();
							mysqli_close($GLOBALS["con"]);
							$boolean =false;
						}
			}
		}
 ?>


	<div class="container">	
		<div class="row">
			<div class="col-sm-2 col-lg-2 col-md-2">	</div>
			<div class="col-sm-8 col-lg-8 col-md-8">	

					<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="username" id="uname" class="form-control" placeholder="enter your name" required>
                  </div>
                  <span id="span"><?php echo $uname; ?></span>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="useremail" id="uemail" class="form-control" placeholder="enter your email" required>
                  </div>
                   <span id="span"><?php echo $uemail; ?></span>
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="userpassword" id="upass" class="form-control" placeholder="enter your password" required>
                  </div>
                   <span id="span"><?php echo $upass; ?></span>
                   <div class="form-group">
                    <label for="password">Confirm Password</label>
                    <input type="password" name="confirmpass" id="comps" class="form-control" placeholder="enter your password" required>
                  </div>
                   <span id="span"><?php echo $comps; ?></span>
                 <!--  <div class="form-group">
                    <label for="phone">Phone</label>
                    <select name="phoneCode" id="phCode">
                      <option selected hidden value="" >Select Code</option>
                      <option value="95">+95</option>
                    </select>
                    <input type="phone" name="phone" id="phno" class="form-control" placeholder="enter your phone no" required>
                  </div> -->
                <center> <button class="btn btn-primary" name="register">Signup</button></center>
                </form>

			</div>
			<div class="col-sm-2 col-md-2 col-lg-2">	</div>
		</div>
	</div>

	
</body>




 <script src="js/jquery.js"></script>
  	<script src="js/jquery-ui-1.10.4.min.js"></script>
  	<script src="js/jquery-1.8.3.min.js"></script>
  	<script>
  		$(document).ready(function(){
  			var $uname = $('#uname');
  			var $uemail = $('#uemail');
  			var $upass = $('#upass');
  			var $ucomfirpas = $('#conps');
  			var $phCode = $('#phCode');
  			var $phno = $('#phno');

  		
  		})
  	</script>
</html>