 <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="index.html" class="logo">Art Gallery</span></a>
      <!--logo end-->

    <!--   <div class="nav search-row" id="top_menu"> -->
        <!--  search form start -->
       <!--  <ul class="nav top-menu">
          <li>
            <form class="navbar-form">
              <input class="form-control" placeholder="Search" type="text">
            </form>
          </li>
        </ul> -->
        <!--  search form end -->
     <!--  </div> -->

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
          <li id="task_notificatoin_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                           Login
                        </a>
            <ul class="dropdown-menu extended tasks-bar" id="loginform">
              <div class="notify-arrow notify-arrow-blue"></div>
              <li>
               
                <form method="post" action="login.php">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="username" id="name" class="form-control" placeholder="enter your name" required>
                  </div>
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="userpassword" id="password" class="form-control" placeholder="enter your password" required>
                  </div>
                  <center> <button class="btn btn-primary" name="login">Login</button></center>
                </form>
              
               
              </li>
            
            </ul>
          </li>
          <!-- task notificatoin end -->
          <!-- inbox notificatoin start-->
          <li id="mail_notificatoin_bar" class="dropdown">
            <a href="register.php" target="blank">
                            Signup
                        </a>
            
          </li>
        
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Home</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_pencil-edit "></i>
                          <span>Paintings</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="watercolor.php">Water Colour Painting</a></li>
              <li><a class="" href="oilpaint.php">Oil Painting</a></li>
               <li><a class="" href="inkwash.php">Ink Wash Painting</a></li>
              <li><a class="" href="acrylicpaint.php">Acrylic Painting</a></li>
               <li><a class="" href="pastelpaint.php">Pastel Colour Painting</a></li>
              <li><a class="" href="glasspaint.php">Glass Painting</a></li>
            </ul>
          </li>
     

          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_images"></i>
                          <span>Gallery</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="creategallery.php">Create Gallery</a></li>
              <li><a class="" href="gallerylist.php"><span>Gallery list</span></a></li>
            </ul>
          </li>

           <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_images"></i>
                          <span>User</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="#" onclick="loginform()">Login</a></li>
              <li><a class="" href="register.php"><span>Signup</span></a></li>
            </ul>
          </li>

        </ul>
        <!-- Hidden login form and signup form -->
        <div id="show" style="display:none">
             <form method="post" action="login.php" >
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="username" id="name" class="form-control" placeholder="enter your name" required>
                  </div>
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="userpassword" id="password" class="form-control" placeholder="enter your password" required>
                  </div>
                <button class="btn btn-primary" name="login">Login</button>&nbsp &nbsp<button class="btn" style="background-color:white;color:black" onclick="cancel()">Cancel</button>
                </form>
        </div>

       
        <!-- End hidden login form and signup form -->

        <!-- sidebar menu end-->
      </div>
    </aside>
    