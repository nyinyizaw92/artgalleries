<?php 
$conn=new mysqli("localhost","root","","artgallery");

 ?>