<?php

include('admin/db1.php');


if(isset($_POST['login']))


{
	if(empty($_POST['username']) || empty($_POST['userpassword']))
	{	
		$message = "<div class='alert alert-danger'>Both fields are required</div>";
	}
	else
	{
		$query = "SELECT * FROM register WHERE username=:username";
		$statement = $bdd->prepare($query);
		$statement->execute(
			array(
				'username' =>$_POST['username']
			)
		);
		$count = $statement->rowCount();
		if($count>0)
		{
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				if(md5($_POST["userpassword"]) == $row["userpassword"])
				{
					session_start();
					$_SESSION['username'] = $row['username'];
					$_SESSION['useremail'] = $row['useremail'];
					$_SESSION['userpassword'] = $row['userpassword'];
					$_SESSION['id'] = $row['id'];
					setcookie("userid",$row['id'],time()+3600);
					setcookie("username",$row['username'],time()+3600);
					setcookie("useremail",$row['useremail'],time()+3600);
					setcookie("userpassword",$row['userpassword'],time()+3600);
					header('location:artgallery.php');
				}
				else
				{
					?>
					<div class="container">
						<center>
							<h4>User name or password wrong</h4>
							<a href="index.php" class="btn btn-sm btn-danger">Ok</a>
						</center>
					</div>
					<?php
				}
			}
		}
		else{
			$message = "<div class='alert alert-danger'>Wrong Email Address</div>";
			$_SESSION['erremail'] = $message;
		}
	}
}
?>